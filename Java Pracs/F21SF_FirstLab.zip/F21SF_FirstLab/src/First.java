/**
 * Software Engineering Foundations
 * A first program
 * Run it, then try altering the text, printing 2 messages, etc
 * @author monica
 *
 */
public class First {
	public static void main (String [] args){
		String name = "Monica";
		System.out.println("Hello " + name);
	}

}
