//F21SF Lecture 5
public class TestName {

	public static void main(String[] args) {
		
		Name n1= new Name("Jane Jo Jones");
		System.out.println(n1.getFullName());

		Name n2 = new Name("Mary", "Ann", "Smith");
		System.out.println(n2.getFullName());
		
		Name n3 = new Name("Lisa", "Brown");
		System.out.println(n3.getFullName());

	}
		
}
