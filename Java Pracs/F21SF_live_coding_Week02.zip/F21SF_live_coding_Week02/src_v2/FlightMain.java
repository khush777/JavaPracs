
public class FlightMain {

	public static void main(String[] args) {

		 // Flight.MILESTOKM;

		
		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 100);
	
		
		
		
		
		int i;
		i = 1;
		System.out.println(i);
		i = i + 1;
		System.out.println(i);
		i++;
		System.out.println(i);
		i += 2;
		System.out.println(i);
		 

	}

}
