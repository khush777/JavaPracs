
public class Airport {
	private String name;
	
	Airport(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
	public String abrv(){
		return "" + name.charAt(0) + name.charAt(1);
	}
}
