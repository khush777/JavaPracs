
public class Flight {
	
	
	public static final double MILESTOKM = 1.64634634;
	
	private Airport from;
	private Airport to;
	int distance; // miles

	public Flight(String fromParam, String to, int distance) {
		this.from = new Airport(fromParam);
		this.to = new Airport(to);
		this.distance = distance;
	}

	public String getDeparture() {
		return this.from.getName();
	}

	public String getDestination() {
		return this.to.getName();
	}

	public int getMilesDistance(){
		return distance;
	}
	
	public double getKMDistance() {
		return distance * MILESTOKM;
	}


	public void setDeparture(Airport from) {
		// 
		this.from = from;
	}
	
	
	public static void main(String[] args) {
		
		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 100);
	
		String city = flightLE.getDeparture();
		System.out.println(city);
		
		/*
		flightLE.to = "Glasgow";
		flightLE.setDeparture(new Airport("Glasgow"));

		
		System.out.println(flightLE.getDeparture());
		
		System.out.println(flightBE.getDeparture());
		
		System.out.println(flightLE.getKMDistance() + " " + flightBE.getKMDistance());
		System.out.println(flightLE.getKMDistance() + flightBE.getKMDistance());
		System.out.println("" + flightLE.getKMDistance() + flightBE.getKMDistance());
		
		System.out.println("Difference between distances:");		
		System.out.println(Math.abs(flightBE.getKMDistance() - flightLE.getKMDistance()));
		 */
		
		
		String flight1 = String.format("%-10s -> %-10s (%7.3f km)", flightLE.getDeparture(), flightLE.getDestination(), flightLE.getKMDistance());
		String flight2 = String.format("%-10s -> %-10s (%7.3f km)", flightBE.getDeparture(), flightBE.getDestination(), flightBE.getKMDistance());
		String flight3 = String.format("%-10s -> %-10s (%7.3f km)", flightBE.getDeparture(), flightBE.getDestination(), 67.9999);
		System.out.println(flight1 );
		System.out.println(flight2 );
		System.out.println(flight3 );

		
		
	}
}
