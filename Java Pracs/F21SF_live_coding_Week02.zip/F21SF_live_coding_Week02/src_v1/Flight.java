
public class Flight {
	private String from;
	String to;
	int distance; // miles

	public Flight(String fromParam, String to, int distance) {
		this.from = fromParam;
		this.to = to;
		this.distance = distance;
	}

	public String getDeparture() {
		return this.from;
	}

	public int getMilesDistance(){
		return distance;
	}
	
	public double getKMDistance() {
		return distance * 1.6;
	}


	public void setDeparture(String from) {
		// 
		this.from = from;
	}
	
}
