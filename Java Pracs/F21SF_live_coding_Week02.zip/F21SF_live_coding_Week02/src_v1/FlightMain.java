
public class FlightMain {

	public static void main(String[] args) {

		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 100);
	
		String city = flightLE.getDeparture();
		System.out.println(city);
		flightLE.to = "Glasgow";
		flightLE.setDeparture("Glasgow");

		System.out.println(flightLE.getDeparture());
		
		System.out.println(flightBE.getDeparture());
		
		System.out.println(flightLE.getMilesDistance() + " " + flightBE.getKMDistance());
		
		
		
		
		
		/*
		int i;
		i = 1;
		System.out.println(i);
		i = i + 1;
		System.out.println(i);
		i++;
		System.out.println(i);
		i += 2;
		System.out.println(i);
		 */

	}

}
