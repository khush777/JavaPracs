
public class FlightMain {

	public static void main(String[] args) {

		 // Flight.MILESTOKM;

		
		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 100);
	
		
		
		
		/*
		int i;
		i = 1;
		System.out.println(i);
		i = i + 1;
		System.out.println(i);
		i++;
		System.out.println(i);
		i += 2;
		System.out.println(i);
		 */
		char b = 'b';
		System.out.println(120 + "45");
		System.out.println(120 + 45);
		System.out.println('b' + 45);
		System.out.println(0 + "abc".charAt(1));
		
		
		System.out.println(2 < 4);
		System.out.println(2 > 4);
		boolean test = 2 > 4;

	}

}
