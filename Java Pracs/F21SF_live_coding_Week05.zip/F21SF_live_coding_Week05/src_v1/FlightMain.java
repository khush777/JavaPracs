
public class FlightMain {

	public static void main(String[] args) {
		
		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 100);

		
		
		String city1 = "Edinburgh";
		String edi = "Edi";
		String city2 = edi + "nburgh";
		String city3 = "Edinburgh";
		String city4 = "Edi" + "nburgh";
		String city5 = new String("Edinburgh");
				
		/* Looking at the difference between ...
		 * ... 
		 * ...*/
		System.out.printf("| city1 and city2 | %s | %s |  == %-5b | .equals %-5b |\n", city1, city2 , city1 == city2, city1.equals(city2));
		System.out.printf("| city1 and city3 | %s | %s |  == %-5b | .equals %-5b |\n", city1, city3 , city1 == city3, city1.equals(city3));
		System.out.printf("| city1 and city4 | %s | %s |  == %-5b | .equals %-5b |\n", city1, city4 , city1 == city4, city1.equals(city4));
		System.out.printf("| city1 and city5 | %s | %s |  == %-5b | .equals %-5b |\n", city1, city5 , city1 == city5, city1.equals(city5));
		
		System.out.println("begin");
		int i = 0;
		while (i < 5) {
			System.out.println("Something " + i);
			if(i==2) {
				i++;
			}
			i ++;
			i++;
		}
		System.out.println("end");
		
		
		// Now division(s)
		int j = 5;
		int k = 2;
		
		System.out.println(4 / 2);
		System.out.println(j / 2.5);
		System.out.println(j / 2.0);
		System.out.println(j / k);
		System.out.println(j % k);
		
		
		// Multiple methods calls
		System.out.println(flightLE.getFrom().abrv());
		Airport a = flightLE.getFrom();
		System.out.println(a.abrv());
		
		
		Flight[] flights = new Flight[5];
		flights[0] = flightLE;
		flights[1] = flightBE;
		
		FlightList flightList = new FlightList();
		
		
	}

}
