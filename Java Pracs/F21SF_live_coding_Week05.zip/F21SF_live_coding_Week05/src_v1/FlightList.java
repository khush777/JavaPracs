import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class FlightList {

	private ArrayList<Flight> flights;
	
	public FlightList() {
		flights = new ArrayList<Flight>();
	}
	
	public void add(Flight flight) {
		flights.add(flight);
	}
	
	private void print1() {
		System.out.println();

		for (int i=0; i < flights.size(); i++) {
			System.out.printf("%d : %s \n", i + 1, flights.get(i).getFlight());
		}
	}
	private void print2() {
		System.out.println();
		for(Flight flight : flights) {
			System.out.printf("%s \n", flight.getFlight());
		}
		
	}

	private void remove(Flight flightBE) {
		flights.remove(flightBE);
	}
	
	
	public void printToCSVFile(String filename) throws IOException {

		// Created an writer object

			FileWriter fw = new FileWriter(filename);
			// write information for each flight
			for(Flight flight : this.flights) {
				fw.write(String.format("%s,%s", flight.getDeparture(),flight.getDestination()));
				// write all prices
				for(int i = 0; i < 3; i++ ) {
					fw.write("," + flight.getPrices()[i]);
				}
				fw.write("\n");
			}
			// closing the writer
			fw.close();
			
			
			
//			try {	
//				FileWriter fw = new FileWriter(filename);
//			} catch (IOException e) {
//				System.out.println("Not doing anything then");
//				System.out.println("But stopping right now");
//				System.exit(5504);
//			}
//			System.out.println("Other things");

		
	}
	
	public void readFromCSVFile(String filename) throws FileNotFoundException {
		// Opening the CSV file
		File file = new File(filename);
		Scanner scanner = new Scanner(file);
		// REading line by line
		while(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			// Splitting the line by item
			String[] items = line.split(",");
			// Converting to int
			
			int price;
			try {
				price = Integer.parseInt(items[2]);
			} catch (NumberFormatException e) {
				price = 100000;
			}
			// creating an flight
			Flight flight = new Flight(items[0], items[1], price);
			// adding the flight to our list
			this.add(flight);
		}
		
	}


	
	
	
	static FlightList populate() {
		// Flight objects
		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 100);
		Flight flightDE = new Flight("Dundee", "Edinburgh", 100);

		// Create a flight list object
		FlightList list = new FlightList();
		// Adding flights to the list
		list.add(flightLE);
		list.add(flightBE);
		list.add(flightDE);
		list.print1();
		list.remove(flightBE);
		list.print1();
		return list;
	}
	

	public static void main(String[] args){
		// Example of accessing program arguments
		// System.out.println(args[1]);
		FlightList l = populate();
		
		l.print1();
		
		
		try {
			l.printToCSVFile("flights_out.csv");
		} catch (IOException e) {
			System.err.println("Incorrect output file");
			System.exit(1);
		}
		
		System.out.println("New list.");
		
		FlightList secondList = new FlightList();
		try {
			secondList.readFromCSVFile("flights_in.csv");
			secondList.print1();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	
}
