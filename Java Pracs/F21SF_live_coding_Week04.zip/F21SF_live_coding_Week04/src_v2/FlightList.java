import java.util.ArrayList;


public class FlightList {

	private ArrayList<Flight> flights;
	
	public FlightList() {
		flights = new ArrayList<Flight>();
	}
	
	public void add(Flight flight) {
		flights.add(flight);
	}
	
	private void print1() {
		System.out.println();

		for (int i=0; i < flights.size(); i++) {
			System.out.printf("%d : %s \n", i + 1, flights.get(i).getFlight());
		}
	}
	private void print2() {
		System.out.println();
		for(Flight flight : flights) {
			System.out.printf("%s \n", flight.getFlight());
		}
		
	}

	private void remove(Flight flightBE) {
		flights.remove(flightBE);
	}
	
	static FlightList populate() {
		// Flight objects
		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 100);
		Flight flightDE = new Flight("Dundee", "Edinburgh", 100);

		// Create a flight list object
		FlightList list = new FlightList();
		// Adding flights to the list
		list.add(flightLE);
		list.add(flightBE);
		list.add(flightDE);
		list.print1();
		list.remove(flightBE);
		list.print1();
		return list;
	}
	

	public static void main(String[] args){
		// Example of accessing program arguments
		// System.out.println(args[1]);
		FlightList l = populate();
		
		l.print1();
		
		
	}


	
}
