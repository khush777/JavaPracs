
public class Flight {
	
	
	public static final double MILESTOKM = 1.64634634;
	
	public static final int FIRSTCLASSARRAYINDEX = 0;
	
	public static final String[] classStrings = { "First", "Second", "Discount" };
	
	
	private Airport from;
	private Airport to;
	int distance; // miles
	// declare and set prices to default int (0)
	private int[] prices = new int[3];
	// private int[] prices = {500, 400, 200};
	// private int[] prices;
	
	/** Instance variable containing the passenger counts per class. */
	private int[] passengers = new int[3] ;
	
	public Flight(String fromParam, String to, int distance) {

		this.from = new Airport(fromParam);
		this.to = new Airport(to);
		this.distance = distance;
		
		// setting the prices according to the distance
		this.prices[FIRSTCLASSARRAYINDEX] = distance;
		this.prices[1] = distance / 5;
		this.prices[2] = distance / 10;
		
	
	}

	public Flight() {
		this.from = new Airport();
		this.to = new Airport();
	
	}

	public Airport getFrom() {
		return from;
	}
	
	public String getDeparture() {
		return this.from.getName();
	}

	public String getDestination() {
		return this.to.getName();
	}

	public int getMilesDistance(){
		return distance;
	}
	
	public double getKMDistance() {
		return distance * MILESTOKM;
	}


	public void setDeparture(Airport from) {
		// 
		this.from = from;
	}
	
	int[] getPrices(){
		return this.prices;
	}
	

	void setPrices(int[] newPrices ){
		// This line only links to the array rather than copy the array for the flight
		// this.prices = newPrices;
		this.prices = newPrices.clone();
	}
	
	void setFirstClassPrice(int price) {
		this.prices[0] = price;
		return;
	}

	void addFirstClassPassengers(int nbNewPassenger) {
		this.passengers[0] += nbNewPassenger;
		return;
	}

	void setSecondClassPrice(int price) {
		this.prices[1] = price;
		return;
	}
	
	/** Adds passengers for the second class. 
	 * @param nbNewPassengers numbers of passengers to add. */
	void addSecondClassPassengers(int nbNewPassengers) {
		this.passengers[1] += nbNewPassengers;
		return;
	}

	int getSecondClassPrice() {
		return this.prices[1];
	}
	
	int getAveragePriceOverClasses() {
		int acc = 0;
		for (int i=0; i <prices.length; i++) {
			// acc = prices[i] + acc;
			acc += prices[i];
			
		}
		int avg = acc / prices.length;
		return avg;
	}

	int getNbPassengers() {
		int nbPassengers = 0;
		for (int j=0; j<passengers.length; j++) {
			nbPassengers += passengers[j];
		}
		return nbPassengers;
	}
	
	int getAveragePrice() {
		int acc = 0;
		for (int i=0; i <prices.length; i++) {
			acc += prices[i] * passengers[i];
		}
		int avg = acc / getNbPassengers();
		return avg;
	}
	
	String getMostPopularClass() {
		int maxNbPassInClass = 0;
		int classIndexMaxNbPass = 0;
		for (int i=0; i <passengers.length; i++) {
			if (passengers[i] > maxNbPassInClass) {
				maxNbPassInClass = passengers[i];
				classIndexMaxNbPass = i;
			}
		}
		
		/* Version without constant array of class strings
		 		
		String classString;

		if (classIndexMaxNbPass == 0) {
			classString = "First";
		} else if (classIndexMaxNbPass == 1) {
			classString = "Second";
		} else {
			classString = "Discount";
		}
		return classString;
		
		*/
		// Version with the constant array of class strings
		return classStrings[classIndexMaxNbPass];
	}
	
	
	boolean hasClassWithoutPassenger() {
		for(int i = 0; i < passengers.length; i++) {
			if (passengers[i] == 0) {
				return true;
			}
		}
		return false;
	}
	
	boolean hasClassWithoutPassengerWhile() {
		int i = 0;
		while(i < passengers.length) {
			if (passengers[i] == 0) {
				return true;
			}
			i++;
		}
		return false;
	}


	String getFlight() {
		return String.format("from %s to %s", this.getDeparture(), this.getDestination());
	}
	
	public static void main(String[] args) {
		
		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 5000);
	
		// flightLE.setPrice(2000);
		
		String flight1 = String.format("%-10s -> %-10s (%7.3f km) %d", flightLE.getDeparture(), flightLE.getDestination(), flightLE.getKMDistance(), flightLE.getPrices()[0]);
		String flight2 = String.format("%-10s -> %-10s (%7.3f km) %d", flightBE.getDeparture(), flightBE.getDestination(), flightBE.getKMDistance(), flightBE.getPrices()[0]);
		System.out.println(flight1 );
		System.out.println(flight2 );

		
		String diff;
		if (flightLE.getMilesDistance() < flightBE.getMilesDistance()) {
			diff = "less";
		} else {
			diff = "more";
		}
		System.out.println("The distance for the flight " + flightLE.getFlight()
				+ " is " + flightLE.getMilesDistance() + " miles, which is "
				+ Math.abs(flightBE.getMilesDistance() - flightLE.getMilesDistance())
				+ " " + diff  + " than " + flightBE.getFlight() + ".");
		
		// Print the array of prices (address)
		System.out.println(flightLE.getPrices());
		// Print the flight (address)		
		System.out.println(flightLE);

		// Print the array of prices
		System.out.println("First class " + flightLE.getPrices()[0]);
		System.out.println("Second class " + flightLE.getPrices()[1]);
		System.out.println("Discount " + flightLE.getPrices()[2]);
		System.out.print("Prices London to Edinburgh:");
		int[] prices = flightLE.getPrices();
		for (int i = 0; i < prices.length ; i++) {
			System.out.print(" " + prices[i]);
		}
		System.out.println();
		System.out.println("Average class price LE: " + flightLE.getAveragePriceOverClasses());
		
		// Adding passengers
		flightLE.addFirstClassPassengers(2);
		flightLE.addSecondClassPassengers(15);
		
		System.out.println("Average price LE: " + flightLE.getAveragePrice());

		// Warning: cells of constant arrays cna be changed
		// classStrings[1]="Other";
		
		System.out.println("Most popular class LE: " + flightLE.getMostPopularClass());

		// Set all prices at once for LE flight
		int[] newPrices = { 50, 50, 50};
		flightLE.setPrices(newPrices);
		
		newPrices[1]=0;
		
		System.out.print("Prices London to Edinburgh:");
		prices = flightLE.getPrices();
		for (int i = 0; i < prices.length ; i++) {
			System.out.print(" " + prices[i]);
		}
		System.out.println();

	}
}
