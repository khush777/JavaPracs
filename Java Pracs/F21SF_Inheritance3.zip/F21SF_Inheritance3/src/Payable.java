
public interface Payable {
	double getPayableAmount();
}
