//Inheritance 3
import java.util.ArrayList;
public class Charity {

	private ArrayList<Person> staffList;
	private ArrayList < Payable> listOfPayables;
	
	public Charity() {
		staffList = new ArrayList<Person> ();
		listOfPayables = new ArrayList<Payable>();
	}
	
	public void populate() {
		Volunteer v1 = new Volunteer (21,new Name("Helen Scott"),
				"helen@hotmail.com", "0131 123 1234",5);
		staffList.add(v1);
		Volunteer v2 = new Volunteer(22, new Name("James Jackson"),
				"james@hotmail.com", "0131 333 3232",10);
		staffList.add(v2);
		Employee e1 = new Employee ("TM3", new Name("Tim Moore"), 
				"tim@hotmail.com", "0131 321 3212", 1500);
		staffList.add(e1);
		listOfPayables.add(e1);

		Employee e2 = new Employee ("MM4", new Name("Mary Munro"), 
				"mary@hotmail.com", "0131 111 1818", 1600);
		staffList.add(e2);
		listOfPayables.add(e2);

		Employee e3 = new Employee ("KC5", new Name("Keith Clark"), 
				"keith@hotmail.com", "0131 989 9898", 2700);
		staffList.add(e3);
		listOfPayables.add(e3);
		
		Invoice i1 = new Invoice("X12", 100);
		listOfPayables.add(i1);	
		
		Invoice i2 = new Invoice("X32", 50);
		listOfPayables.add(i2);			
	}

	
	//returns a text list of all names for everyone in the staff list
	//names are defined in the Person superclass
	public String listAllNames()
	{
		String list = "ALL STAFF\n";
		for (Person p : staffList){
			String fullName =  p.getName().getFullName(); 	
			list += fullName + "\n";	
		}
		list += "\n";
		return list;
	}

	//returns a text list of details for everyone in the staff list
	//uses toString method defined in the subclass
	public String listDetails()
	{
		String list = "ALL STAFF DETAILS\n";
		for (Person p : staffList){	
			list += p.toString() + "\n\n";	
		}
		return list;
	}
	
	//totalling hours, using an abstract method specified in Person superclass
	//and implemented in both subclasses
	public int getTotalHours() {
		int total = 0;
		for (Person p : staffList) {
			total += p.getMonthlyHours();
		}
		return total;
	}
	
	//totalling payable amount, using method specified in Payable interface
	// and implemented by both sub-classes
	public int getTotalPayable() {
		int total = 0;
		for (Payable p : listOfPayables)
		{
			total += p.getPayableAmount();
		}
		return  total;
	}


}
