//Inheritance 3
public class InheritanceDemo3 {

	public static void main(String[] args) {
		
		Charity charity = new Charity();
		charity.populate();
		System.out.println("Total hours is " + charity.getTotalHours());
		System.out.println("Total payable is �" + charity.getTotalPayable());
	}

}
