
public class Invoice implements Payable
{
	private String id;
	private int numItems ;
	private static final int COST_EACH_ITEM = 5;
	
	public Invoice(String id, int n){
		this.id = id;
		numItems = n;
	}
	
	public String toString() {
		return id + " " + numItems;
	}
	
	 public double getPayableAmount()
	 {
	   return numItems*COST_EACH_ITEM;
	 }

}
