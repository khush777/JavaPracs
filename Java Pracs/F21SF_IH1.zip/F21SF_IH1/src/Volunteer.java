//SEF Inheritance 1
public class Volunteer extends Person
{
    private int vID;
    private int monthlyHours;

    public Volunteer (int vID, Name n, String e, 
							String p, int h)
    {
    	super(n, e, p);   
    	this.vID = vID;
    	monthlyHours = h;
    }
    
    public int getID() { return vID; }
    public int getMonthlyHours(){return monthlyHours; }
    
}
