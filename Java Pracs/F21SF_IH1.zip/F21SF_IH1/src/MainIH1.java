//Inheritance 1
//Shows Volunteer and Employee subclasses of Person
//Held in a list of staff. 
//Methods in CharityStaff only access Person attributes
public class MainIH1 {

	public static void main(String[] args) {
		IHDemo1 demo = new IHDemo1();
		demo.run();

	}
}
