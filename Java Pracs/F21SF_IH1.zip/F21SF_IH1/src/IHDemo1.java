//Example of using an Employee subclass
//Examples of using CharityStaff methods
//which use Person methods
public class IHDemo1 {
	private CharityStaff charity;
	
	public IHDemo1() {
		charity = new CharityStaff();
	}

	public void run() {
		//create an employee
		Employee e = new Employee("GB11", new Name("Gordon Blair"),
				"gordon@macs.hw", "0141 1111 2222", 1500);
		
		//print out some Employee specific data
		//using subclass methods
		System.out.print("Employee specific data: ");
		System.out.println(e.getID() + "  �" + e.getMonthlySalary());
		
		//use superclass methods to get some Staff data
		//and print it
		System.out.print("Staff data : ");
		System.out.println(e.getName().getFullName());
		

		//populate and print a mixture of volunteers and employees	
		charity.populate();
		System.out.println("===================================");
		System.out.println(charity.listAllNames());
		System.out.println("===================================");
		System.out.println(charity.listAllVolunteers());
		System.out.println("===================================");
		System.out.println(charity.listVolunteerIDs());
		System.out.println("+++++++++++++++++++++++++");
		printPersonDetails("May Smith");
		printPersonDetails("Tim Moore");
		printPersonDetails("Helen Scott");
	}
	
	private void printPersonDetails(String name) {
		Person p = charity.findPerson(name);
		if (p == null) {
			System.out.println(name + " is not in the list");
		}
		else if (p instanceof Volunteer) {
			System.out.println(name + " is a volunteer");
		}
		else if (p instanceof Employee) {
			System.out.println(name + " is an employee");
		}
		else  // don't expect to come here
			System.out.println(name + " is in the list " +
					"but is not an emloyee or a volunteer");
	}

}
