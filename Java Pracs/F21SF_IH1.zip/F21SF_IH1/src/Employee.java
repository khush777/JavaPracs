//SEF Inheritance 1
public class Employee extends Person 
{
    private String eID;
    private double monthlySalary;
    private static final int HOURS = 20;
    
    public Employee (String eID, Name n, String e, 
							String p, double s)
    {
    	super(n, e, p); 
    	this.eID = eID; 
    	monthlySalary = s;
    }
    
    public String getID() { return eID; }
    public double getMonthlySalary(){return monthlySalary; }
    public int getMonthlyHours()  {  return HOURS;  }
       
}
