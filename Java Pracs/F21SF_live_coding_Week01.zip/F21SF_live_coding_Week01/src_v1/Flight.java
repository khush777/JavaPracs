
public class Flight {
	String from;
	String to;
	int distance; // miles

	public Flight(String fromParam, String to, int distance) {
		from = fromParam;
		this.to = to;
		this.distance = distance;
	}

}
