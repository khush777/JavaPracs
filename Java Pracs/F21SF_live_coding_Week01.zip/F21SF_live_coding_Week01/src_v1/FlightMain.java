
public class FlightMain {

	public static void main(String[] args) {

		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 100);
		
	}

}
