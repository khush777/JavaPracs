
public class Flight {
	
	
	public static final double MILESTOKM = 1.64634634;
	
	private Airport from;
	private Airport to;
	int distance; // miles
	private int price;

	public Flight(String fromParam, String to, int distance) {

		this.from = new Airport(fromParam);
		this.to = new Airport(to);
		this.distance = distance;
	
	
	}

	public Flight() {
		this.from = new Airport();
		this.to = new Airport();
	
	}

	public String getDeparture() {
		return this.from.getName();
	}

	public String getDestination() {
		return this.to.getName();
	}

	public int getMilesDistance(){
		return distance;
	}
	
	public double getKMDistance() {
		return distance * MILESTOKM;
	}


	public void setDeparture(Airport from) {
		// 
		this.from = from;
	}
	
	int getPrice(){
		return this.price;
	}
	
	void setPrice(int price) {
		this.price = price;
		return;
	}
	
	String getFlight() {
		return String.format("from %s to %s", this.getDeparture(), this.getDestination());
	}
	
	public static void main(String[] args) {
		
		Flight flightLE = new Flight("London", "Edinburgh", 400);
		Flight flightBE = new Flight("Barra", "Edinburgh", 5000);
	
		flightLE.setPrice(2000);
		
		String flight1 = String.format("%-10s -> %-10s (%7.3f km) %d", flightLE.getDeparture(), flightLE.getDestination(), flightLE.getKMDistance(), flightLE.getPrice());
		String flight2 = String.format("%-10s -> %-10s (%7.3f km) %d", flightBE.getDeparture(), flightBE.getDestination(), flightBE.getKMDistance(), flightBE.getPrice());
		System.out.println(flight1 );
		System.out.println(flight2 );

		
		String diff;
		if (flightLE.getMilesDistance() < flightBE.getMilesDistance()) {
			diff = "less";
		} else {
			diff = "more";
		}
		System.out.println("The distance for the flight " + flightLE.getFlight()
				+ " is " + flightLE.getMilesDistance() + " miles, which is "
				+ Math.abs(flightBE.getMilesDistance() - flightLE.getMilesDistance())
				+ " " + diff  + " than " + flightBE.getFlight() + ".");
		
		
	}
}
