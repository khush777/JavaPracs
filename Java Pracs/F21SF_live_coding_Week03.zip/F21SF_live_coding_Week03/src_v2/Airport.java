
/** Our Airport class
 * @author Manuel
 */
public class Airport {
	private String city;
	private String name;
	private String code;
	
	/*
	Airport(String city, String code) {
		this.city = city;
		this.code = code;
	}
	*/

	Airport(String city, String airportName) {
		this.city = city;
		this.name = airportName;
	}
	
	Airport(String city){
		this.city = city;
	}
	
	public Airport() {
	}

	
	public String getName(){
		return city;
	}
	
	/** 
	 * Gives the abbreviation of the airport.
	 * @return String of the abbreviation
	 *  */
	public String abrv(){
		return "" + city.charAt(0) + city.charAt(1);
	}
	
	public void print(){
		if(name.equals("")) {
			System.out.printf("%s\n", city);
		} else {
			System.out.printf("%s (%s)\n", city, name);
		}
	}
	
	
	public static void main(String[] args) {
		Airport edi = new Airport ("Edinburgh");
		Airport lhr = new Airport ("London", "Heathrow");

		System.out.println(lhr.abrv());
		lhr.print();
		edi.print();
		
		
	}
}
