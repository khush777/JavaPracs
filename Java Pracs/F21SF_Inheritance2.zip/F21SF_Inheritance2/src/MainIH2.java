
public class MainIH2 {

	public static void main(String[] args) {
		CharityStaff charity = new CharityStaff();
		charity.populate();
		System.out.print(charity.listDetails() );
		System.out.println("Total hours worked is " + charity.getTotalHours());

	}

}
